-- Tabela de Usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha VARCHAR(100) NOT NULL
);

-- Tabela de Comentários da Comunidade
CREATE TABLE IF NOT EXISTS comentarios_comunidade (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    conteudo TEXT NOT NULL,
    data_postagem DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de Políticos
CREATE TABLE IF NOT EXISTS politicos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cargo VARCHAR(50) NOT NULL,
    partido VARCHAR(50) NOT NULL,
    estado VARCHAR(2) NOT NULL
);

-- Tabela de Propostas
CREATE TABLE IF NOT EXISTS propostas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    descricao TEXT NOT NULL,
    autor_id INT,
    FOREIGN KEY (autor_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de Salvos (propostas ou políticos salvos pelos usuários)
CREATE TABLE IF NOT EXISTS salvos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    tipo ENUM('proposta', 'politico') NOT NULL,
    referencia_id INT NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    UNIQUE (usuario_id, tipo, referencia_id)
);

INSERT INTO politicos (nome, cargo, partido, estado) VALUES
('João Silva', 'Deputado Federal', 'Partido Verde', 'SP'),
('Maria Souza', 'Senadora', 'Partido Azul', 'RJ'),
('Carlos Oliveira', 'Governador', 'Partido Laranja', 'MG'),
('Ana Costa', 'Vereadora', 'Partido Rosa', 'BA');

INSERT INTO propostas (titulo, descricao) VALUES
('PL 123/2024 - Transporte Público Gratuito', 'Institui o transporte gratuito para estudantes e idosos.'),
('PEC 89/2024 - Reforma Tributária', 'Altera os artigos da constituição sobre arrecadação de impostos.');