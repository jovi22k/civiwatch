const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const path = require('path');

const app = express();
const db = require('./db');

app.use(session({ secret: 'secret', resave: true, saveUninitialized: true }));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.redirect('/login');
});

app.get('/login', (req, res) => {
    res.render('login', { error: null });
});

app.post('/login', (req, res) => {
    const { email, senha } = req.body;
    if (email && senha) {
        db.query('SELECT * FROM usuarios WHERE email = ? AND senha = ?', [email, senha], (err, results) => {
            if (results.length > 0) {
                req.session.loggedin = true;
                req.session.nome = results[0].nome;
                req.session.usuario_id = results[0].id;
                res.redirect('/principal');
            } else {
                res.render('login', { error: 'Credenciais inválidas.' });
            }
        });
    } else {
        res.render('login', { error: 'Preencha todos os campos.' });
    }
});

app.get('/cadastro', (req, res) => {
    res.render('cadastro', { error: null });
});

app.post('/cadastro', (req, res) => {
    const { nome, email, senha } = req.body;
    if (nome && email && senha) {
        db.query('INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)', [nome, email, senha], (err) => {
            if (err) throw err;
            res.redirect('/login');
        });
    } else {
        res.render('cadastro', { error: 'Todos os campos são obrigatórios.' });
    }
});

app.get('/principal', (req, res) => {
    if (req.session.loggedin) {
        res.render('principal', { nome: req.session.nome });
    } else {
        res.redirect('/login');
    }
});

app.get('/home', (req, res) => {
    res.render('home');
});

// PERFIL com dados
app.get('/perfil', (req, res) => {
    const usuarioId = req.session.usuario_id;

    if (!usuarioId) return res.redirect('/login');

    db.query('SELECT * FROM usuarios WHERE id = ?', [usuarioId], (err, results) => {
        if (err) {
            console.error('Erro ao carregar perfil:', err);
            return res.status(500).send('Erro no servidor');
        }

        const usuario = results[0];
        res.render('perfil', { usuario });
    });
});

// FORMULÁRIO DE EDIÇÃO
app.get('/editar-perfil', (req, res) => {
    const usuarioId = req.session.usuario_id;
    if (!usuarioId) return res.redirect('/login');

    db.query('SELECT * FROM usuarios WHERE id = ?', [usuarioId], (err, results) => {
        if (err) return res.status(500).send('Erro ao carregar perfil');
        res.render('editarPerfil', { usuario: results[0] });
    });
});

// SALVAR EDIÇÃO
app.post('/editar-perfil', (req, res) => {
    const usuarioId = req.session.usuario_id;
    const { nome, email } = req.body;

    if (!usuarioId) return res.redirect('/login');

    db.query('UPDATE usuarios SET nome = ?, email = ? WHERE id = ?', [nome, email, usuarioId], (err) => {
        if (err) return res.status(500).send('Erro ao atualizar perfil');
        req.session.nome = nome;
        res.redirect('/perfil');
    });
});


// ROTA COMUNIDADE - GET
app.get('/comunidade', (req, res) => {
    if (!req.session.usuario_id) return res.redirect('/login');

    const sql = `
        SELECT c.id, c.conteudo, c.data_postagem, u.nome,
        LOWER(SUBSTRING_INDEX(u.email, '@', 1)) AS usuario,
        TIMESTAMPDIFF(MINUTE, c.data_postagem, NOW()) AS minutos
        FROM comentarios_comunidade c
        JOIN usuarios u ON c.usuario_id = u.id
        ORDER BY c.data_postagem DESC
    `;

    db.query(sql, (err, results) => {
        if (err) {
            console.error(err);
            return res.render('comunidade', { comentarios: [] });
        }

        const comentarios = results.map(c => ({
            ...c,
            tempo: c.minutos < 60 ? `${c.minutos} min atrás` :
                   c.minutos < 1440 ? `${Math.floor(c.minutos / 60)}h atrás` :
                   `${Math.floor(c.minutos / 1440)}d atrás`
        }));

        res.render('comunidade', { comentarios });
    });
});

// ROTA COMUNIDADE - POST
app.post('/comunidade', (req, res) => {
    if (!req.session.usuario_id) return res.redirect('/login');

    const { conteudo } = req.body;
    db.query(
        'INSERT INTO comentarios_comunidade (usuario_id, conteudo) VALUES (?, ?)',
        [req.session.usuario_id, conteudo],
        (err) => {
            if (err) {
                console.error('Erro ao inserir comentário:', err);
            }
            res.redirect('/comunidade');
        }
    );
});



app.get('/propostas', (req, res) => {
    db.query('SELECT * FROM propostas', (err, results) => {
        if (err) {
            console.error('Erro ao buscar propostas:', err);
            return res.render('propostas', { propostas: [] });
        }
        res.render('propostas', { propostas: results });
    });
});


app.get('/politicos', (req, res) => {
    db.query('SELECT * FROM politicos', (err, results) => {
        if (err) {
            console.error('Erro ao buscar políticos:', err);
            return res.status(500).send('Erro no servidor');
        }
        res.render('politicos', { politicos: results });
    });
});

app.post('/salvar-politico', (req, res) => {
    const usuarioId = req.session.usuario_id;
    const { politico_id } = req.body;

    if (!usuarioId) return res.redirect('/login');

    db.query(
        'INSERT IGNORE INTO salvos (usuario_id, tipo, referencia_id) VALUES (?, ?, ?)',
        [usuarioId, 'politico', politico_id],
        (err) => {
            if (err) {
                console.error('Erro ao salvar político:', err);
                return res.status(500).send('Erro ao salvar político');
            }
            res.redirect('/salvos');
        }
    );
});

app.get('/salvos', (req, res) => {
    const usuarioId = req.session.usuario_id;
    if (!usuarioId) return res.redirect('/login');

    const sql = `
        SELECT p.* FROM salvos s
        JOIN politicos p ON s.referencia_id = p.id
        WHERE s.usuario_id = ? AND s.tipo = 'politico'
    `;

    db.query(sql, [usuarioId], (err, results) => {
        if (err) {
            console.error('Erro ao buscar salvos:', err);
            return res.status(500).send('Erro no servidor');
        }
        res.render('salvos', { politicos: results });
    });
});

app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) console.error('Erro ao encerrar sessão:', err);
        res.redirect('/login');
    });
});


// ROTA GET /propostas
app.get('/propostas', (req, res) => {
    db.query('SELECT * FROM propostas', (err, results) => {
        if (err) {
            console.error('Erro ao buscar propostas:', err);
            return res.status(500).send('Erro no servidor');
        }
        res.render('propostas', { propostas: results });
    });
});

// ROTA POST /salvar-proposta
app.post('/salvar-proposta', (req, res) => {
    const usuarioId = req.session.usuario_id;
    const propostaId = req.body.proposta_id;

    if (!usuarioId) return res.redirect('/login');

    db.query(
        'INSERT IGNORE INTO salvos (usuario_id, tipo, referencia_id) VALUES (?, ?, ?)',
        [usuarioId, 'proposta', propostaId],
        (err) => {
            if (err) {
                console.error('Erro ao salvar proposta:', err);
                return res.status(500).send('Erro ao salvar');
            }
            res.redirect('/salvos');
        }
    );
});

// ROTA GET /salvos (politicos + propostas)
app.get('/salvos', (req, res) => {
    const usuarioId = req.session.usuario_id;
    if (!usuarioId) return res.redirect('/login');

    const sql = `
        SELECT 'politico' AS tipo, p.id, p.nome, p.cargo AS detalhe, p.partido AS extra
        FROM salvos s
        JOIN politicos p ON s.referencia_id = p.id
        WHERE s.usuario_id = ? AND s.tipo = 'politico'
        UNION ALL
        SELECT 'proposta' AS tipo, pr.id, pr.titulo AS nome, pr.descricao AS detalhe, '' AS extra
        FROM salvos s
        JOIN propostas pr ON s.referencia_id = pr.id
        WHERE s.usuario_id = ? AND s.tipo = 'proposta'
        ORDER BY tipo, nome
    `;

    db.query(sql, [usuarioId, usuarioId], (err, results) => {
        if (err) {
            console.error('Erro ao buscar salvos:', err);
            return res.status(500).send('Erro ao carregar salvos');
        }
        res.render('salvos', { salvos: results });
    });
});


app.listen(3000, () => console.log('Servidor rodando em http://localhost:3000'));
